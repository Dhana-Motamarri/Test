import * as dateFns from "date-fns";

export default dateFns;
