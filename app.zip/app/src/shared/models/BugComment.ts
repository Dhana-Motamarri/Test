export interface BugComment {
  id: string;
  text: string;
  commenter: string;
  commentedAt: string;
}
